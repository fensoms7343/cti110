#CTI110
#P4T1a
#Scott Fensom
#11/20/18

import turtle
win = turtle.Screen()
t = turtle.Turtle()

t.pensize(8)
t.color("red")
t.shape('turtle')

#creates the triangle
for i in (1,2,3):
    t.forward(100)
    t.left(120)
#creates the square
for i in (1,2,3,4):
    t.forward(100)
    t.right(90)
