#CTI110
#P4T1b
#Scott Fensom
#11/15/18

import turtle           #lets you use turtle
win = turtle.Screen()   #creates the screen to see turtle
t = turtle.Turtle()     #creates the turtle and assigns it a name

t.pensize(8)
t.color('red')
t.shape('turtle')

#Write the first and last initials of my name

#Write the S
t.penup()
t.goto (-150,150)
t.pendown()
t.backward(100)
t.right(90)
t.forward(100)
t.left(90)
t.forward(100)
t.right(90)
t.forward(100)
t.right(90)
t.forward(100)

#Write the F
t.penup()
t.goto(0,150)
t.pendown()
t.forward(100)
t.left(90)
t.forward(75)
t.left(90)
t.forward(75)
t.backward(75)
t.right(90)
t.forward(125)

t.penup()
t.forward(50)



