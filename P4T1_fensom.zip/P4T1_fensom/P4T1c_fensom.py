#CTI110
#P4T1c
#Scott Fensom
#11/20/18

import turtle
import random
win = turtle.Screen()
t = turtle.Turtle()
win.bgcolor("cyan")

t.screen.tracer (5,-5)
t.speed (100000)
t.pensize (2)
sfcolor = ["red", "blue", "black", "green", "orange", "black"]

def shape(size):
    for b in range(1):
        t.color(random.choice(sfcolor))
        for l in range(10):
            t.forward(75*size/3)
            t.right(36)
            for i in (1,2,3,4,5):
                t.forward(50*size/3)
                t.right(72)
                for j in (1,2,3):
                    t.forward(75*size/3)
                    t.left(120)
                    for k in range (3):
                        t.forward (10*size/3)
                        t.right (120)
for z in range(10):
    t.right(175)
    x = random.randint(-400, 400)
    y = random.randint(-400, 400)
    sf_size = random.randint(1, 4)
    t.penup()
    t.goto(x, y)
    t.pendown()
    shape(sf_size)
    

win.exitonclick()
